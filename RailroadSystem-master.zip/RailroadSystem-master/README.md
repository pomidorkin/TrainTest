# Railroad System for Unity using Cinemachine

- Install Unity 2019.4LTS (with URP, otherwise you have to change materials) 
- Install Cinemachine package
- Install Input System package
- Download and install RailroadSystem package from this repository

Here's the corresponding video tutorial:

[![Alt tutorial video](https://img.youtube.com/vi/ViVVgjqf2XA/0.jpg)](https://www.youtube.com/watch?v=ViVVgjqf2XA)
